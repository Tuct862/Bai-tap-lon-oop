// Chuyển đổi giữa form đăng nhập và đăng ký
function toggleForm() {
    var loginSection = document.getElementById('login-section');
    var registerSection = document.getElementById('register-section');
    var formTitle = document.getElementById('form-title');
    
    if (loginSection.classList.contains('active')) {
        loginSection.classList.remove('active');
        registerSection.classList.add('active');
        formTitle.innerText = 'Đăng ký Kí túc xá';
    } else {
        registerSection.classList.remove('active');
        loginSection.classList.add('active');
        formTitle.innerText = 'Đăng nhập Kí túc xá';
    }
}

// Hàm xử lý đăng nhập
function login() {
    var email = document.getElementById('login-email').value;
    var password = document.getElementById('login-password').value;
    var errorMessage = document.getElementById('login-error-message');
    
    var validEmail = 'student@st.phenikaa-uni.edu.vn';
    var validPassword = 'password123';

    if (!email.endsWith('@st.phenikaa-uni.edu.vn')) {
        errorMessage.innerText = 'Email phải có đuôi @st.phenikaa-uni.edu.vn';
        errorMessage.style.display = 'block';
    } else if (email !== validEmail || password !== validPassword) {
        errorMessage.innerText = 'Tài khoản mật khẩu không đúng';
        errorMessage.style.display = 'block';
    } else {
        errorMessage.style.display = 'none';
        alert('Đăng nhập thành công!');
    }
}

// Hàm xử lý đăng ký
function register() {
    var name = document.getElementById('register-name').value;
    var email = document.getElementById('register-email').value;
    var password = document.getElementById('register-password').value;
    var errorMessage = document.getElementById('register-error-message');

    if (!name || !email || !password) {
        errorMessage.innerText = 'Vui lòng điền đầy đủ thông tin';
        errorMessage.style.display = 'block';
    } else if (!email.endsWith('@st.phenikaa-uni.edu.vn')) {
        errorMessage.innerText = 'Email phải có đuôi @st.phenikaa-uni.edu.vn';
        errorMessage.style.display = 'block';
    } else {
        errorMessage.style.display = 'none';
        alert('Đăng ký thành công!');
        // Sau khi đăng ký thành công, chuyển về form đăng nhập
        toggleForm();
    }
}
