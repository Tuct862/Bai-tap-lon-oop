$(document).ready(function() {
    const roomData = [
        { room: "101", amount: 100000, paid: false },
        { room: "102", amount: 200000, paid: true },
        { room: "103", amount: 150000, paid: false }
    ];

    function updateRoomTable() {
        $("#roomTableBody").empty();
        roomData.forEach((roomInfo, index) => {
            const qrCode = `<img src="https://api.qrserver.com/v1/create-qr-code/?data=${roomInfo.amount}" alt="QR Code" style="width: 50px;">`;
            const status = roomInfo.paid ? "Đã Thanh Toán" : "Chưa Thanh Toán";
            const toggleButton = `<button onclick="togglePaymentStatus(${index})">${roomInfo.paid ? 'Đánh Dấu Chưa Thanh Toán' : 'Đánh Dấu Đã Thanh Toán'}</button>`;

            $("#roomTableBody").append(`
                <tr>
                    <td>${roomInfo.room}</td>
                    <td>${roomInfo.amount.toLocaleString()} VND</td>
                    <td>${status}</td>
                    <td>${toggleButton}</td>
                    <td>${qrCode}</td>
                </tr>
            `);
        });
    }

    $("#sendPayment").click(function() {
        const roomNumber = $("#roomNumber").val();
        const amount = $("#amount").val();

        if (amount) {
            roomData.forEach(roomInfo => {
                if (roomInfo.room === roomNumber) {
                    roomInfo.amount = parseInt(amount);
                    roomInfo.paid = false; // Mặc định là chưa thanh toán
                }
            });
            updateRoomTable();
            $("#amount").val(''); // Xóa input sau khi gửi
        }
    });

    window.togglePaymentStatus = function(index) {
        roomData[index].paid = !roomData[index].paid;
        updateRoomTable();
    }

    updateRoomTable();
});
