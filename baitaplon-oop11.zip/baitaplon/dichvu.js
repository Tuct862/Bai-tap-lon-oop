let rooms = [];
let services = {};

// Thêm phòng mới
document.getElementById('roomForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const roomType = document.getElementById('roomType').value;
    const roomNumber = document.getElementById('roomNumber').value;
    
    const room = {
        type: roomType,
        number: roomNumber
    };

    rooms.push(room);
    displayRooms();
    populateRoomOptions(); // Cập nhật danh sách phòng trong select
    this.reset(); // Reset form
});

// Hiển thị danh sách phòng
function displayRooms() {
    const tableBody = document.getElementById('roomTable').getElementsByTagName('tbody')[0];
    tableBody.innerHTML = '';
    
    rooms.forEach((room, index) => {
        const row = tableBody.insertRow();
        
        const roomTypeCell = row.insertCell();
        roomTypeCell.textContent = `${room.type}-người`;
        
        const roomNumberCell = row.insertCell();
        roomNumberCell.textContent = room.number;

        const actionCell = row.insertCell();
        actionCell.innerHTML = `<button onclick="deleteRoom(${index})">Xóa phòng</button>`;
    });
}

// Xóa phòng
function deleteRoom(index) {
    rooms.splice(index, 1);
    displayRooms();
    populateRoomOptions(); // Cập nhật danh sách phòng trong select
}

// Cập nhật danh sách phòng vào các dropdown menu
function populateRoomOptions() {
    const selectRoom = document.getElementById('selectRoom');
    const itemRoom = document.getElementById('itemRoom');
    selectRoom.innerHTML = '';
    itemRoom.innerHTML = '';

    rooms.forEach(room => {
        const option = document.createElement('option');
        option.value = `${room.type}-${room.number}`;
        option.textContent = `Phòng ${room.number} (${room.type}-người)`;
        selectRoom.appendChild(option);
        itemRoom.appendChild(option.cloneNode(true));
    });
}

// Thêm dịch vụ cho phòng
document.getElementById('serviceForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const selectedRoom = document.getElementById('selectRoom').value;
    const serviceName = document.getElementById('serviceName').value;

    if (!services[selectedRoom]) {
        services[selectedRoom] = [];
    }

    services[selectedRoom].push(serviceName);
    displayServices();
    this.reset(); // Reset form
});

// Hiển thị danh sách dịch vụ theo phòng
function displayServices() {
    const tableBody = document.getElementById('serviceTable').getElementsByTagName('tbody')[0];
    tableBody.innerHTML = '';
    
    Object.keys(services).forEach(room => {
        services[room].forEach((service, index) => {
            const row = tableBody.insertRow();
            
            const roomCell = row.insertCell();
            roomCell.textContent = room;
            
            const serviceNameCell = row.insertCell();
            serviceNameCell.textContent = service;

            const actionCell = row.insertCell();
            actionCell.innerHTML = `<button onclick="deleteService('${room}', ${index})">Xóa dịch vụ</button>`;
        });
    });
}

// Xóa dịch vụ
function deleteService(room, index) {
    services[room].splice(index, 1);
    if (services[room].length === 0) {
        delete services[room]; // Xóa phòng khỏi danh sách nếu không còn dịch vụ nào
    }
    displayServices();
}

// Kiểm tra tình trạng đồ dùng trong phòng
function checkItems() {
    const selectedRoom = document.getElementById('itemRoom').value;
    let itemStatus = '';

    // Cung cấp tình trạng đồ dùng dựa trên loại phòng
    if (selectedRoom.includes('2')) {
        itemStatus = 'Phòng 2 người có 2 giường, 2 quạt, 1 tủ quần áo, 1 nhà vệ sinh, 1 bình nước.';
    } else if (selectedRoom.includes('4')) {
        itemStatus = 'Phòng 4 người có 4 giường, 4 quạt, 1 tủ quần áo, 1 nhà vệ sinh, 1 bình nước.';
    } else if (selectedRoom.includes('6')) {
        itemStatus = 'Phòng 6 người có 6 giường, 6 quạt, 1 tủ quần áo, 1 nhà vệ sinh, 1 bình nước.';
    }

    // Hiển thị thêm các dịch vụ nếu có
    if (services[selectedRoom]) {
        itemStatus += ' Dịch vụ đã thêm: ' + services[selectedRoom].join(', ') + '.';
    }

    // Hiển thị trạng thái đồ dùng
    document.getElementById('itemStatus').textContent = itemStatus;
}
