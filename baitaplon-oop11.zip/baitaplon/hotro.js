let feedbacks = []; // Mảng lưu trữ ý kiến

// Gửi ý kiến từ các phòng
document.getElementById('feedbackForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Ngăn chặn hành động gửi mặc định của form

    const roomNumber = document.getElementById('roomNumber').value;
    const feedbackMessage = document.getElementById('feedbackMessage').value;

    // Tạo đối tượng ý kiến mới
    const feedback = {
        room: roomNumber,
        message: feedbackMessage,
        status: 'Chưa phản hồi', // Trạng thái ban đầu
        response: '' // Phản hồi sẽ được thêm sau
    };

    feedbacks.push(feedback); // Thêm ý kiến vào mảng
    displayFeedbacks(); // Hiển thị lại danh sách ý kiến
    this.reset(); // Đặt lại form
});

// Hiển thị danh sách ý kiến
function displayFeedbacks() {
    const tableBody = document.getElementById('feedbackTable').getElementsByTagName('tbody')[0];
    tableBody.innerHTML = ''; // Xóa nội dung cũ

    feedbacks.forEach((feedback, index) => {
        const row = tableBody.insertRow(); // Thêm hàng mới
        
        const roomCell = row.insertCell(); // Thêm ô cho phòng
        roomCell.textContent = feedback.room; // Gán nội dung phòng

        const messageCell = row.insertCell(); // Thêm ô cho nội dung ý kiến
        messageCell.textContent = feedback.message; // Gán nội dung ý kiến

        const statusCell = row.insertCell(); // Thêm ô cho trạng thái
        statusCell.textContent = feedback.status; // Gán trạng thái

        const actionCell = row.insertCell(); // Thêm ô cho phản hồi
        // Nếu chưa phản hồi, hiển thị nút phản hồi
        if (feedback.status === 'Chưa phản hồi') {
            actionCell.innerHTML = `<button onclick="respondFeedback(${index})">Phản hồi</button>`;
        } else {
            actionCell.textContent = feedback.response; // Hiển thị phản hồi nếu đã có
        }
    });
}

// Mở form phản hồi
function respondFeedback(index) {
    document.getElementById('feedbackIndex').value = index; // Lưu chỉ số của ý kiến cần phản hồi
    document.getElementById('responseSection').style.display = 'block'; // Hiển thị phần phản hồi
}

// Gửi phản hồi từ admin
document.getElementById('responseForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Ngăn chặn hành động gửi mặc định của form

    const index = document.getElementById('feedbackIndex').value; // Lấy chỉ số của ý kiến
    const responseMessage = document.getElementById('responseMessage').value; // Lấy nội dung phản hồi

    // Cập nhật trạng thái và phản hồi cho ý kiến
    feedbacks[index].status = 'Đã phản hồi'; // Cập nhật trạng thái
    feedbacks[index].response = responseMessage; // Cập nhật phản hồi

    displayFeedbacks(); // Hiển thị lại danh sách ý kiến
    document.getElementById('responseSection').style.display = 'none'; // Ẩn phần phản hồi
    this.reset(); // Đặt lại form phản hồi
});
