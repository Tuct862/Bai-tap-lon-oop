let students = []; // Mảng lưu trữ thông tin sinh viên

document.getElementById('studentForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Ngăn chặn hành động gửi mặc định của form
    
    const studentIndex = document.getElementById('studentIndex').value;
    const name = document.getElementById('name').value;
    const age = document.getElementById('age').value;
    const gender = document.getElementById('gender').value;
    const studentId = document.getElementById('studentId').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;

    const student = {
        name,
        age,
        gender,
        studentId,
        email,
        phone
    };

    if (studentIndex === '-1') {
        // Nếu không sửa, thêm mới sinh viên
        students.push(student);
    } else {
        // Nếu sửa, cập nhật thông tin sinh viên
        students[studentIndex] = student;
    }

    // Hiển thị danh sách sinh viên
    displayStudents();
    resetForm();
});

// Hàm hiển thị danh sách sinh viên
function displayStudents() {
    const tableBody = document.getElementById('studentTable').getElementsByTagName('tbody')[0];
    tableBody.innerHTML = ''; // Xóa nội dung cũ

    students.forEach((student, index) => {
        const row = tableBody.insertRow();

        Object.values(student).forEach((value) => {
            const cell = row.insertCell();
            cell.textContent = value;
        });

        // Tạo nút sửa và xóa
        const actionCell = row.insertCell();
        actionCell.innerHTML = `<button onclick="editStudent(${index})">Sửa</button>
                                <button onclick="deleteStudent(${index})">Xóa</button>`;
    });
}

// Hàm sửa thông tin sinh viên
function editStudent(index) {
    const student = students[index];
    
    document.getElementById('studentIndex').value = index;
    document.getElementById('name').value = student.name;
    document.getElementById('age').value = student.age;
    document.getElementById('gender').value = student.gender;
    document.getElementById('studentId').value = student.studentId;
    document.getElementById('email').value = student.email;
    document.getElementById('phone').value = student.phone;
}

// Hàm xóa thông tin sinh viên
function deleteStudent(index) {
    students.splice(index, 1); // Xóa sinh viên khỏi mảng
    displayStudents(); // Hiển thị lại danh sách sinh viên
}

// Hàm đặt lại form
function resetForm() {
    document.getElementById('studentForm').reset();
    document.getElementById('studentIndex').value = '-1'; // Đặt lại chỉ số
}
