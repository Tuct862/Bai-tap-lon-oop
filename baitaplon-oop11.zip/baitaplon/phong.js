let rooms = []; // Mảng lưu trữ thông tin các phòng

document.getElementById('roomForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Ngăn hành động gửi mặc định của form
    
    const roomType = document.getElementById('roomType').value;
    const roomNumber = document.getElementById('roomNumber').value;
    
    const room = {
        roomType: roomType,
        roomNumber: roomNumber,
        students: [] // Danh sách sinh viên trong phòng
    };
    
    rooms.push(room);
    displayRooms(); // Hiển thị lại danh sách phòng
    this.reset(); // Đặt lại form
});

// Hiển thị danh sách phòng
function displayRooms() {
    const tableBody = document.getElementById('roomTable').getElementsByTagName('tbody')[0];
    tableBody.innerHTML = ''; // Xóa nội dung cũ
    
    rooms.forEach((room, roomIndex) => {
        const row = tableBody.insertRow();
        
        const roomTypeCell = row.insertCell();
        roomTypeCell.textContent = `${room.roomType}-người`;
        
        const roomNumberCell = row.insertCell();
        roomNumberCell.textContent = room.roomNumber;
        
        const studentsCell = row.insertCell();
        if (room.students.length > 0) {
            const studentList = room.students.map((student, studentIndex) => {
                return `${student} <button onclick="deleteStudent(${roomIndex}, ${studentIndex})">Xóa</button>`;
            }).join(', ');
            studentsCell.innerHTML = studentList;
        } else {
            studentsCell.textContent = 'Chưa có sinh viên';
        }
        
        const actionCell = row.insertCell();
        actionCell.innerHTML = `<button onclick="deleteRoom(${roomIndex})">Xóa phòng</button>`;
    });
}

// Hàm xóa phòng
function deleteRoom(index) {
    rooms.splice(index, 1); // Xóa phòng khỏi mảng
    displayRooms(); // Hiển thị lại danh sách phòng
}

// Thêm sinh viên vào phòng
document.getElementById('studentForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Ngăn hành động gửi mặc định của form
    
    const studentName = document.getElementById('studentName').value;
    const studentRoomNumber = document.getElementById('studentRoomNumber').value;
    
    // Tìm phòng có số phòng trùng khớp
    const room = rooms.find(r => r.roomNumber === studentRoomNumber);
    
    if (room) {
        if (room.students.length < parseInt(room.roomType)) {
            room.students.push(studentName);
            displayRooms(); // Hiển thị lại danh sách phòng
        } else {
            alert(`Phòng ${studentRoomNumber} đã đầy!`);
        }
    } else {
        alert(`Không tìm thấy phòng với số ${studentRoomNumber}!`);
    }
    
    this.reset(); // Đặt lại form
});

// Hàm xóa sinh viên ra khỏi phòng
function deleteStudent(roomIndex, studentIndex) {
    rooms[roomIndex].students.splice(studentIndex, 1); // Xóa sinh viên khỏi danh sách
    displayRooms(); // Hiển thị lại danh sách phòng
}
